


function sub(){

	var doc= document.getElementById('email').value;

	alert(doc + ", you are subscribe.");
	


};


	